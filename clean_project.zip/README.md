# Cinema BRtv - App IPTV (somente APP, sem painel por enquanto)

✅ Projeto completo **React Native + Expo**  
✅ Tudo em **horizontal (landscape)**: login, home e player  
✅ Login estilo **Xtream**: URL/Host + usuário + senha  
✅ Carrega categorias e canais via `player_api.php`  
✅ Player toca canal via URL `/live/USER/PASS/STREAM_ID.(m3u8|ts)`  
✅ Pronto para upload no Manus IA / GitHub / EAS

## Importante (compatibilidade)
- Expo/`expo-av` costuma funcionar melhor com **HLS (.m3u8)**.
- Se o seu servidor fornecer apenas `.ts`, use a Configuração para mudar para `ts`.
- Alguns servidores podem bloquear players móveis. Isso depende do servidor.

## Rodar local
1) `npm install`
2) `npm run start`

## Gerar APK
Use EAS:
- `npm i -g eas-cli`
- `eas build:configure`
- `eas build -p android --profile preview`

## Futuro: painel administrativo
O app está organizado com `services/` e `storage/` para você adicionar depois:
- Validação de plano/trial
- Bloqueio por Device ID
- Temas remotos
Veja `FUTURO_PAINEL.md`.
