# Compilar APK via GitHub Actions (Expo EAS)

## Pré-requisitos
1) Conta no Expo (expo.dev)
2) Gerar um token em: Expo Dashboard -> Access Tokens

## Configurar Secret
No GitHub do repositório:
Settings -> Secrets and variables -> Actions -> New repository secret

- Nome: EXPO_TOKEN
- Valor: (cole o token do Expo)

## Como rodar
- Push na branch main **ou**
- Actions -> Build Android APK (Expo EAS) -> Run workflow

## Onde baixar o APK
O EAS imprime um link de download no log do job.
