
package com.cinemabrtv.ui.home
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cinemabrtv.R
import com.cinemabrtv.ui.player.PlayerActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        findViewById<android.view.View>(R.id.btnPlay).setOnClickListener {
            val i = Intent(this, PlayerActivity::class.java)
            i.putExtra("url","https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8")
            startActivity(i)
        }
    }
}
