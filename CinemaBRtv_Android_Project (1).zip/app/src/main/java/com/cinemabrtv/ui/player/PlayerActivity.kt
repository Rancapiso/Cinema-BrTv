
package com.cinemabrtv.ui.player
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cinemabrtv.R
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

class PlayerActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        player = ExoPlayer.Builder(this).build()
        val view = findViewById<com.google.android.exoplayer2.ui.PlayerView>(R.id.playerView)
        view.player = player
        val url = intent.getStringExtra("url")!!
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.play()
    }
    override fun onDestroy() {
        super.onDestroy()
        player.release()
    }
}
